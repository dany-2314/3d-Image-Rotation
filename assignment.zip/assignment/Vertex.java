package assignment;

class Vertex extends GraphicalObject {
	
	double x,y,z;
	
	public Vertex(double x, double y, double z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}
	
	public void transform(double[][] matrix) {
		double x_prime = (matrix[0][0] * this.x) + (matrix[0][1] * this.y) + (matrix[0][2] * this.z);
		double y_prime = (matrix[1][0] * this.x) + (matrix[1][1] * this.y) + (matrix[1][2] * this.z);
		double z_prime = (matrix[2][0] * this.x) + (matrix[2][1] * this.y) + (matrix[2][2] * this.z);
		this.x = x_prime;
		this.y = y_prime;
		this.z = z_prime;
	}
	
	@Override
	public int hashCode() {
		return (int)(5*x + 6*y + 7*z); // look into this further
	}
	
	@Override
	public boolean equals(Object obj) {
		
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		
		Vertex other = (Vertex) obj;
		if (this.x != other.x)
			return false;
		if (this.y != other.y)
			return false;
		if (this.z != other.z)
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return String.valueOf(x) + " " + String.valueOf(y) + " " + String.valueOf(z);
	}
}
