package assignment;

public class Driver {

	public static void main(String[] args) {
		
		
	Mesh mesh = new Mesh();
	mesh.setReader(new OBJMeshReader());
	mesh.readFromFile("D:\\code\\Java Code\\A1\\src\\assignment\\car.obj");
	mesh.rotateYAxis(Math.PI/3); // -> problem happens here
	mesh.setWriter(new OBJMeshWriter());
	mesh.writeToFile("D:\\code\\Java Code\\A1\\src\\assignment\\car_rotated.obj");
    mesh.setWriter(new PLYMeshWriter());
    mesh.writeToFile("D:\\code\\Java Code\\A1\\src\\assignment\\car_rotated.ply");
		
	}

}
