package assignment;

import java.util.LinkedHashSet;

class Polygon extends GraphicalObject{

	LinkedHashSet<Vertex> vertices;
	
	public Polygon(LinkedHashSet<Vertex> vertices) {
		this.vertices = new LinkedHashSet<Vertex>(vertices); 
	}
	
	public void transform(double[][] matrix) {
		for (Vertex v : this.vertices)
			v.transform(matrix);
	}
	
	@Override
	public int hashCode() {
		int hash = 0;
		for (Vertex v:vertices)
			hash = hash + ((int)(5*v.x + 6*v.y + 7*v.z));
		return hash;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		
		Polygon other = (Polygon) obj;
		
		if (this.vertices.size() == other.vertices.size()) {
			for(Vertex v1 : vertices) {
				if (!other.vertices.contains(v1))
					return false;
			}
		}
		else 
			return false;
		
		return true;
	}
	
}
