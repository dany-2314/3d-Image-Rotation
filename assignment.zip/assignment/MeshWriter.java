package assignment;

import java.util.HashSet;

public interface MeshWriter {
	public abstract void write(String filename, HashSet<Polygon> polygons);
}
