package assignment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedHashSet;

public class OBJMeshReader implements MeshReader {
	
	@Override
	public HashSet<Polygon> read(String filename){
		
		LinkedHashSet<Vertex> vertexList = new LinkedHashSet<Vertex>(); // list of all our vertex
		LinkedHashSet<Vertex> vertices = new LinkedHashSet<Vertex>(); // the vertex to add in a polygon
		HashSet<Polygon> faces = new HashSet<Polygon>();
		
		try {
		 	File f = new File(filename);
	 
		 	
		 		//making file readable
		 		BufferedReader obj = new BufferedReader(new FileReader(f)); // reads OBJ file
		 		
		 		String line;
		 		while((line = obj.readLine()) != null) {
		 			
		 			String[] parse = line.split("\\s"); // parse each line by whitespace
		 			
		 			if (parse[0].equals("v")) 
		 				vertexList.add( new Vertex(Double.parseDouble(parse[1]), Double.parseDouble(parse[2]), Double.parseDouble(parse[3])) ); // stores each vertex in OBJ in order
		 			else if (parse[0].equals("f")) {
		 				// make polygon
		 				vertices.removeAll(vertices); // checks and removes the vertice before we start adding so we can add the specific order
		 				for (int i = 1; i < parse.length; i++) {
		 					
		 					//this is bad code(start)
		 					int counter = 1;
		 					 
		 					for(Vertex v: vertexList) {    //-> goes through each vertex in vertexList and keeps adding it in vertices which we will pass to a polygon 
		 						if (counter == Integer.parseInt(parse[i])) {
		 							vertices.add(new Vertex(v.x, v.y, v.z));
		 							
		 							break;
		 						}
		 						
		 						counter++;
		 					}
		 					//(end)
		 				}
		 				
		 				faces.add(new Polygon(vertices));
		 			}
		 				
		 		}
		 		obj.close();
		 	
		} catch (IOException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();  
			} 
		if (vertices.isEmpty()) 
			return null;
		return faces;
	}
}
