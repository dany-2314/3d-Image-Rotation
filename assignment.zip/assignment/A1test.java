package assignment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.LinkedHashSet;

import org.junit.jupiter.api.Test;

class A1test {

	
	@Test
	void VertexTest() {
		Vertex v1 = new Vertex(1,2,3);
		Vertex v3 = new Vertex(1,3,3);
		Vertex v2 = new Vertex(1,2,6);
		Vertex v4 = new Vertex(0,2,3);
		Vertex v5 = new Vertex(1,2,3);
		
		LinkedHashSet<Vertex> p = new LinkedHashSet<Vertex>();
		assertEquals(v1.hashCode(), 38);
		assertEquals(v1.equals(v1), true);
		assertEquals(v1.equals(null), false);
		assertEquals(v1.equals(new Polygon(p)), false);
		assertEquals(v1.equals(v2), false);
		assertEquals(v1.equals(v3), false);
		assertEquals(v1.equals(v4), false);
		assertEquals(v1.equals(v3), false);
		assertEquals(v1.equals(v5), true);
		assertEquals(v5.equals(v1), true);
		
		assertEquals(v1.toString(), "1.0 2.0 3.0");
		
		v1.rotateYAxis(Math.PI/3);
		assertEquals(v1.x, 3.098076211353316);
		assertEquals(v1.y, 2);
		assertEquals(v1.z, 0.6339745962155618);
		
		v1.rotateXAxis(Math.PI/3);
		assertEquals(v1.x, 3.098076211353316);
		assertEquals(v1.y, 0.4509618943233419);
		assertEquals(v1.z, 2.049038105676658);
		
		v1.rotateZAxis(Math.PI/3);
		assertEquals(v1.x, 1.158493649053891);
		assertEquals(v1.y, 2.90849364905389);
		assertEquals(v1.z, 2.049038105676658);
	}

	@Test
	void PolygonTest() {
		
		Vertex v1 = new Vertex(1,2,3);
		Vertex v3 = new Vertex(1,3,3);
		Vertex v2 = new Vertex(1,2,6);
		Vertex v4 = new Vertex(0,2,3);
		Vertex v5 = new Vertex(1,2,3);
		LinkedHashSet<Vertex> p = new LinkedHashSet<Vertex>();
		p.add(v1);
		p.add(v2);
		p.add(v3);
		p.add(v4);
		p.add(v5);
		Polygon poly = new Polygon(p);
		assertEquals(poly.hashCode(), 174); // -> value calculated manually
		assertEquals(poly.hashCode(), poly.hashCode()); //-> to test the same polygon gives the same hashcode
		
		LinkedHashSet<Vertex> p2 = new LinkedHashSet<Vertex>();
		p2.add(new Vertex(1,2,3));
		p2.add(new Vertex(1,3,3));
		p2.add(new Vertex(1,2,6));
		p2.add(new Vertex(0,2,3));
	
		LinkedHashSet<Vertex> p3 = new LinkedHashSet<Vertex>();
		p3.add(new Vertex(1,7,3));
		p3.add(new Vertex(1,3,3));
		p3.add(new Vertex(1,2,6));
		p3.add(new Vertex(0,2,3));
		
		
		Polygon poly2 = new Polygon(p2);
		Polygon poly3 = new Polygon(p3);
		
		LinkedHashSet<Vertex> p4 = new LinkedHashSet<Vertex>();
		p4.add(new Vertex(1,3,3));
		p4.add(new Vertex(1,2,6));
		p4.add(new Vertex(0,8,3));
		
		
		Polygon poly4 = new Polygon(p4);
		
		assertEquals(poly.equals(v1), false);
		assertEquals(poly.equals(null), false);
		assertEquals(poly.equals(new Polygon(p)), true);
		assertEquals(poly.equals(poly), true);
		assertEquals(poly.equals(poly3), false);
		assertEquals(poly3.equals(poly), false);
		assertEquals(poly.equals(poly2), true);
		assertEquals(poly2.equals(poly), true);
		assertEquals(poly2.equals(poly4), false);
		
		//checking transform of 1 vertex in polygon
		Vertex v = new Vertex(1,2,3);
		Vertex x = new Vertex(1,2,5);
		LinkedHashSet<Vertex> f = new LinkedHashSet<Vertex>();
		f.add(new Vertex(v.x, v.y, v.z));
		f.add(new Vertex(x.x, x.y, x.z));
		// both polygons are the same
		Polygon f1 = new Polygon(f);
		Polygon f2 = new Polygon(f);
		// since rotate works properly as indicated in vertex
		// will show it changes all the vertex in polygon too
		
		assertTrue(f1.equals(f2)); // to show polygons are same ie vertices are same
		
		f1.rotateXAxis(Math.PI);
		
		assertFalse(f1.equals(f2)); // proving the vertices change
	}

	@Test
	void MeshTest() {
		Mesh mesh = new Mesh();
		mesh.setReader(new OBJMeshReader());
		mesh.readFromFile("D:\\code\\Java Code\\A1\\src\\assignment\\testobj.obj");
		
		assertEquals(mesh.hashCode(), 0); // value manually calculated
		
		Mesh mesh2 = new Mesh();
		mesh2.setReader(new OBJMeshReader());
		mesh2.readFromFile("D:\\code\\Java Code\\A1\\src\\assignment\\testobj.obj");
		
		assertEquals(mesh.equals(mesh2), true);
		assertEquals(mesh.equals(mesh), true);
		assertEquals(mesh.equals(null), false);
		assertEquals(mesh.equals(new Vertex(1,2,3)), false);
		
		// tests if 2 mesh is smaller than the other
		Mesh mesh3 = new Mesh();
		mesh3.setReader(new OBJMeshReader());
		mesh3.readFromFile("D:\\code\\Java Code\\A1\\src\\assignment\\testobj2.obj");
		assertEquals(mesh.equals(mesh3), false);
		
		// tests if 2 mesh is different (different faces)
		Mesh mesh4 = new Mesh();
		mesh4.setReader(new OBJMeshReader());
		mesh4.readFromFile("D:\\code\\Java Code\\A1\\src\\assignment\\testobj3.obj");
		assertEquals(mesh.equals(mesh4), false);
		
		// testing transform on a mesh with 2 polygons with 1 vertex
		Vertex v1 = new Vertex(1,2,0);
		Vertex v1_test = new Vertex(v1.x, v1.y, v1.z); // will be using referenceing to show vertices change in mesh.transform
		LinkedHashSet<Vertex> p1 = new LinkedHashSet<Vertex>();
		p1.add(v1_test);
		
		Vertex v2 = new Vertex(1,0,1);
		Vertex v2_test = new Vertex(v2.x, v2.y, v2.z); // will be using referenceing to show vertices change in mesh.transform
		LinkedHashSet<Vertex> p2 = new LinkedHashSet<Vertex>();
		p2.add(v2_test);
		
		Mesh meshTest = new Mesh();
		meshTest.polygons.add(new Polygon(p1));
		meshTest.polygons.add(new Polygon(p2));
		
		assertTrue(v1.equals(v1_test)); // showing that the vertices are equal before rotate
		assertTrue(v2.equals(v2_test));
		
		meshTest.rotateYAxis(Math.PI); // cause vertices to change, indiretly testing mesh.transform
		
		assertFalse(v1.equals(v1_test)); // showing that the vertices are not equal after rotate
	}

	@Test
	void OBJMeshReader() {
		// file does not exist checker
		Mesh m = new Mesh();
		m.setReader( new OBJMeshReader());
		m.readFromFile("no file test"); // gives file DNE in console
		m.readFromFile("D:\\code\\Java Code\\A1\\src\\assignment\\testobj.obj");
		
		Mesh m_expected = new Mesh();
		Vertex v1 = new Vertex(-0.5,0,0.5);
		Vertex v2 = new Vertex(0.5,0,0.5);
		Vertex v3 = new Vertex(0.5,0,-0.5);
		Vertex v4 = new Vertex(-0.5,0,-0.5);
		LinkedHashSet<Vertex> f1 = new LinkedHashSet<Vertex>();
		LinkedHashSet<Vertex> f2 = new LinkedHashSet<Vertex>();
		f1.add(v1);
		f1.add(v2);
		f1.add(v4);
		
		f2.add(v2);
		f2.add(v3);
		f2.add(v4);
		
		m_expected.polygons.add(new Polygon(f1));
		m_expected.polygons.add(new Polygon(f2));
		
		assertTrue(m.equals(m_expected));
		
		Mesh m2 = new Mesh();
		m2.setReader( new OBJMeshReader());
		m2.readFromFile("D:\\code\\Java Code\\A1\\src\\assignment\\garbagedata.obj"); // garabge data
		assertEquals(m2.polygons, null); // shows m2 polygons is empty after garbage data input
		
		m.readFromFile("dfwd");
	}

	@Test
	void testOBJMeshWriter() {
		Mesh m = new Mesh();
		Vertex v1 = new Vertex(-0.5,0,0.5);
		Vertex v2 = new Vertex(0.5,0,0.5);
		Vertex v3 = new Vertex(0.5,0,-0.5);
		Vertex v4 = new Vertex(-0.5,0,-0.5);
		LinkedHashSet<Vertex> f1 = new LinkedHashSet<Vertex>();
		LinkedHashSet<Vertex> f2 = new LinkedHashSet<Vertex>();
		f1.add(v1);
		f1.add(v2);
		f1.add(v4);
		
		f2.add(v2);
		f2.add(v3);
		f2.add(v4);
		
		m.polygons.add(new Polygon(f1));
		m.polygons.add(new Polygon(f2));
		
		m.setWriter(new OBJMeshWriter());
		m.writeToFile("D:\\code\\Java Code\\A1\\src\\assignment\\writeobj.obj");
		
		Mesh m2 = new Mesh();
		m2.setReader(new OBJMeshReader());
		m2.readFromFile("D:\\code\\Java Code\\A1\\src\\assignment\\writeobj.obj");
		assertTrue(m.equals(m2));
		m.writeToFile("");
	}
	
	@Test
	void PLYMeshReader() {
		// file does not exist checker
		Mesh m = new Mesh();
		m.setReader( new PLYMeshReader());
		m.readFromFile("no file test"); // gives file DNE in console
		m.readFromFile("D:\\code\\Java Code\\A1\\src\\assignment\\testply.ply");
		
		Mesh m_expected = new Mesh();
		Vertex v1 = new Vertex(-0.5,0,0.5);
		Vertex v2 = new Vertex(0.5,0,0.5);
		Vertex v3 = new Vertex(0.5,0,-0.5);
		Vertex v4 = new Vertex(-0.5,0,-0.5);
		LinkedHashSet<Vertex> f1 = new LinkedHashSet<Vertex>();
		LinkedHashSet<Vertex> f2 = new LinkedHashSet<Vertex>();
		f1.add(v1);
		f1.add(v2);
		f1.add(v4);
		
		f2.add(v2);
		f2.add(v3);
		f2.add(v4);
		
		m_expected.polygons.add(new Polygon(f1));
		m_expected.polygons.add(new Polygon(f2));
		
		assertTrue(m.equals(m_expected));
		
		Mesh m2 = new Mesh();
		m2.setReader( new PLYMeshReader());
		m2.readFromFile("D:\\code\\Java Code\\A1\\src\\assignment\\garbagedata.ply"); // garabge data
		assertEquals(m2.polygons, null); // shows m2 polygons is empty after garbage data input
		
		m.readFromFile("dfwd");
	}
	
	@Test
	void testPLYMeshWriter() {
		Mesh m = new Mesh();
		Vertex v1 = new Vertex(-0.5,0,0.5);
		Vertex v2 = new Vertex(0.5,0,0.5);
		Vertex v3 = new Vertex(0.5,0,-0.5);
		Vertex v4 = new Vertex(-0.5,0,-0.5);
		LinkedHashSet<Vertex> f1 = new LinkedHashSet<Vertex>();
		LinkedHashSet<Vertex> f2 = new LinkedHashSet<Vertex>();
		f1.add(v1);
		f1.add(v2);
		f1.add(v4);
		
		f2.add(v2);
		f2.add(v3);
		f2.add(v4);
		
		m.polygons.add(new Polygon(f1));
		m.polygons.add(new Polygon(f2));
		
		m.setWriter(new PLYMeshWriter());
		m.writeToFile("D:\\code\\Java Code\\A1\\src\\assignment\\writeply.ply");
		
		Mesh m2 = new Mesh();
		m2.setReader(new PLYMeshReader());
		m2.readFromFile("D:\\code\\Java Code\\A1\\src\\assignment\\writeply.ply");
		assertTrue(m.equals(m2));
		
		m.writeToFile("");
	}
	
	
}

