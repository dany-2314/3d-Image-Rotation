package assignment;


import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;

public class OBJMeshWriter implements MeshWriter {
	@Override
	public void write(String filename, HashSet<Polygon> polygons) {
		
		// create an arraylist that stores all vertices
		ArrayList<Vertex> vertices = new ArrayList<Vertex>();
		
		// go through each element in polygons
		for (Polygon p : polygons)
			// go through each vertices
			for (Vertex v : p.vertices) {
				// check if vertex exists in vertices
				if (!vertices.contains(v))
					vertices.add(new Vertex(v.x, v.y, v.z));	
			}
		
		
		try {
			// assuming file already exists
			FileWriter obj = new FileWriter(filename);
			// write the vertices first
			for (Vertex v : vertices)
				obj.write("v" + " " + v.toString() + "\n"); //-> in format "v D D D" where D is decimal value
			// write the faces last
			for (Polygon p : polygons) {
				String v_pos = ""; // index of each vertex in face
				for (Vertex v : p.vertices)
					v_pos += " " + Integer.toString(vertices.indexOf(v) + 1);
				
				obj.write("f" + v_pos + "\n");	//-> in format "f Int Int Int"
			}
			obj.close();
		} catch (IOException e) {
			System.out.println("Error has occured");
			e.printStackTrace();
		}
	}
}
