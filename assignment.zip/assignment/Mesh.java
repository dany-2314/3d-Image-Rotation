package assignment;

import java.util.HashSet;

class Mesh extends GraphicalObject {
	
	HashSet<Polygon> polygons = new HashSet<Polygon>();
	MeshReader reader;
	MeshWriter writer;
	
	public void setReader(MeshReader mr) {
		reader = mr;
	}
	
	public void setWriter(MeshWriter mw) {
		writer = mw;
	}
	
	public void readFromFile(String file) {
		polygons = reader.read(file);
	}
	
	public void writeToFile(String file) {
		writer.write(file,  polygons);
	}
	
	public void transform(double[][] matrix) {
		for(Polygon p : polygons)
			p.transform(matrix);
	}
	
	@Override
	public int hashCode() {
		int hash = 0;
		for(Polygon p : polygons)
			hash += p.hashCode();
		return hash;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		
		Mesh other = (Mesh)obj;
		if (other.polygons.size() != this.polygons.size())
			return false;
		for (Polygon p : other.polygons) {
			if (polygons.contains(p) == false)
				return false;
		}
		return true;
	}
	
}
