package assignment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedHashSet;

public class PLYMeshReader implements MeshReader {

	@Override
	public HashSet<Polygon> read(String filename){
		
		LinkedHashSet<Vertex> vertexList = new LinkedHashSet<Vertex>(); // list of all our vertex
		LinkedHashSet<Vertex> vertices = new LinkedHashSet<Vertex>(); // the vertex to add in a polygon
		HashSet<Polygon> faces = new HashSet<Polygon>();
		boolean checker = false; // checks if the vertex and face list started 
		int num_vertex = 0; //number of vertex in PLY
		int i = 1;
		
		try {
		 	File f = new File(filename);
	 
		 		//making file readable
		 		BufferedReader ply = new BufferedReader(new FileReader(f)); // reads PLY file
		 		
		 		String line;
		 		while((line = ply.readLine()) != null) {
		 			
		 			String[] parse = line.split("\\s"); // parse each line by whitespace
		 			
		 			// gets the number of vertices
		 			if ((parse[0].equals("element")) && (parse[1].equals("vertex")))
		 				num_vertex = Integer.parseInt(parse[2]);
		 			
		 			// vertex and face list starts next line
		 			else if (parse[0].equals("end_header"))
		 				checker = true;
		 			
		 			// starts to create polygon and vertex list
		 			if((checker == true) && (parse[0].equals("end_header") == false) ) {
		 				// adds all the vertices
		 				if(i <= num_vertex) {
		 					vertexList.add(new Vertex(
		 							Double.parseDouble(parse[0]), 
		 							Double.parseDouble(parse[1]), 
		 							Double.parseDouble(parse[2]))
		 							);
		 					i++;
		 				}
		 				// adds all the faces
		 				else {
		 					vertices.removeAll(vertices);
		 					for (int j = 1; j < parse.length; j++) {
			 					
			 					//this is bad code(start)
			 					int counter = 0;
			 					 
			 					for(Vertex v: vertexList) {    //-> goes through each vertex in vertexList and keeps adding it in vertices which we will pass to a polygon 
			 						if (counter == Integer.parseInt(parse[j])) {
			 							vertices.add(new Vertex(v.x, v.y, v.z));
			 							break;
			 						}
			 						
			 						counter++;
			 					}
			 					//(end)
			 				}
			 				faces.add(new Polygon(vertices));
		 				}
		 			}
		 		}
		 		ply.close();
		 	 
		 		System.out.println("file DNE");
		} catch (IOException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();  
			}
		if (vertices.isEmpty()) 
			return null;
		return faces;
	}
}
